package gui;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

public class FrmConHistorialMedico extends JInternalFrame {

	private JTextField txtBuscar;
	private JTable tblPacientes;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {

					FrmConHistorialMedico frame = new FrmConHistorialMedico();
					frame.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmConHistorialMedico() {

		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setResizable(true);
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);

		setTitle("Consulta de Historial Médico");
		setBounds(100, 100, 900, 680);

		getContentPane().setLayout(null);
		getContentPane().setBackground(
				new Color(224, 255, 255));

		// =====================================================
		// CABECERA
		// =====================================================

		JPanel panelCabecera = new JPanel();
		panelCabecera.setBackground(
				new Color(52, 73, 94));

		panelCabecera.setBounds(0, 0, 884, 70);
		panelCabecera.setLayout(null);

		getContentPane().add(panelCabecera);

		JLabel lblTitulo = new JLabel(
				"CONSULTA DE HISTORIAL MÉDICO");

		lblTitulo.setForeground(Color.WHITE);
		lblTitulo.setFont(
				new Font("Tahoma", Font.BOLD, 20));

		lblTitulo.setBounds(25, 12, 400, 25);

		panelCabecera.add(lblTitulo);

		JLabel lblDescripcion = new JLabel(
				"Consulta y visualización de información del paciente");

		lblDescripcion.setForeground(
				new Color(220, 220, 220));

		lblDescripcion.setFont(
				new Font("Tahoma", Font.PLAIN, 12));

		lblDescripcion.setBounds(27, 40, 400, 20);

		panelCabecera.add(lblDescripcion);

		// =====================================================
		// PANEL DE BÚSQUEDA
		// =====================================================

		JPanel panelBusqueda = new JPanel();

		panelBusqueda.setBackground(Color.WHITE);
		panelBusqueda.setLayout(null);

		panelBusqueda.setBorder(
				new TitledBorder(
						new LineBorder(
								new Color(200, 205, 210)),
						"Buscar paciente",
						TitledBorder.LEFT,
						TitledBorder.TOP,
						new Font("Tahoma", Font.BOLD, 12),
						new Color(52, 73, 94)));

		panelBusqueda.setBounds(20, 85, 844, 75);

		getContentPane().add(panelBusqueda);

		JLabel lblBuscar = new JLabel(
				"DNI / N.º Historial:");

		lblBuscar.setFont(
				new Font("Tahoma", Font.BOLD, 12));

		lblBuscar.setBounds(20, 30, 130, 25);

		panelBusqueda.add(lblBuscar);

		txtBuscar = new JTextField();

		txtBuscar.setBounds(155, 30, 300, 25);

		panelBusqueda.add(txtBuscar);

		JButton btnBuscar = new JButton("Buscar");

		btnBuscar.setFont(
				new Font("Tahoma", Font.BOLD, 12));

		btnBuscar.setBounds(475, 29, 100, 27);

		panelBusqueda.add(btnBuscar);

		JButton btnMostrarTodos = new JButton(
				"Mostrar todos");

		btnMostrarTodos.setFont(
				new Font("Tahoma", Font.PLAIN, 12));

		btnMostrarTodos.setBounds(590, 29, 120, 27);

		panelBusqueda.add(btnMostrarTodos);

		// =====================================================
		// TABLA DE PACIENTES
		// =====================================================

		JPanel panelResultados = new JPanel();

		panelResultados.setBackground(Color.WHITE);
		panelResultados.setLayout(null);

		panelResultados.setBorder(
				new TitledBorder(
						new LineBorder(
								new Color(200, 205, 210)),
						"Pacientes encontrados",
						TitledBorder.LEFT,
						TitledBorder.TOP,
						new Font("Tahoma", Font.BOLD, 12),
						new Color(52, 73, 94)));

		panelResultados.setBounds(20, 175, 844, 145);

		getContentPane().add(panelResultados);

		String[] columnas = {
				"Historial",
				"DNI",
				"Nombres",
				"Apellidos",
				"Fecha nacimiento",
				"Sexo"
		};

		DefaultTableModel modelo =
				new DefaultTableModel(columnas, 0);

		// Datos de ejemplo solamente para visualizar la tabla

		modelo.addRow(new Object[] {
				"HM-70294511-4",
				"70294511",
				"Juan",
				"Pérez García",
				"15/04/1998",
				"Masculino"
		});

		modelo.addRow(new Object[] {
				"HM-75842136-2",
				"75842136",
				"María",
				"Lopez Torres",
				"23/08/2000",
				"Femenino"
		});

		tblPacientes = new JTable(modelo);

		tblPacientes.setFont(
				new Font("Tahoma", Font.PLAIN, 11));

		tblPacientes.setRowHeight(25);

		tblPacientes.getTableHeader().setFont(
				new Font("Tahoma", Font.BOLD, 11));

		JScrollPane scrollTabla =
				new JScrollPane(tblPacientes);

		scrollTabla.setBounds(10, 25, 824, 105);

		panelResultados.add(scrollTabla);

		// =====================================================
		// DATOS DEL PACIENTE
		// =====================================================

		JPanel panelDatos = new JPanel();

		panelDatos.setBackground(Color.WHITE);
		panelDatos.setLayout(null);

		panelDatos.setBorder(
				new TitledBorder(
						new LineBorder(
								new Color(200, 205, 210)),
						"Información del paciente",
						TitledBorder.LEFT,
						TitledBorder.TOP,
						new Font("Tahoma", Font.BOLD, 12),
						new Color(52, 73, 94)));

		panelDatos.setBounds(20, 335, 410, 200);

		getContentPane().add(panelDatos);

		JLabel lblNombre = new JLabel(
				"Nombres:");

		lblNombre.setFont(
				new Font("Tahoma", Font.BOLD, 12));

		lblNombre.setBounds(20, 35, 100, 25);

		panelDatos.add(lblNombre);

		JLabel lblValorNombre =
				new JLabel("Juan Pérez");

		lblValorNombre.setBounds(
				125, 35, 240, 25);

		panelDatos.add(lblValorNombre);

		JLabel lblDni = new JLabel(
				"DNI:");

		lblDni.setFont(
				new Font("Tahoma", Font.BOLD, 12));

		lblDni.setBounds(20, 65, 100, 25);

		panelDatos.add(lblDni);

		JLabel lblValorDni =
				new JLabel("70294511");

		lblValorDni.setBounds(
				125, 65, 240, 25);

		panelDatos.add(lblValorDni);

		JLabel lblFecha = new JLabel(
				"Fecha nacimiento:");

		lblFecha.setFont(
				new Font("Tahoma", Font.BOLD, 12));

		lblFecha.setBounds(
				20, 95, 110, 25);

		panelDatos.add(lblFecha);

		JLabel lblValorFecha =
				new JLabel("15/04/1998");

		lblValorFecha.setBounds(
				135, 95, 230, 25);

		panelDatos.add(lblValorFecha);

		JLabel lblSexo = new JLabel(
				"Sexo:");

		lblSexo.setFont(
				new Font("Tahoma", Font.BOLD, 12));

		lblSexo.setBounds(
				20, 125, 100, 25);

		panelDatos.add(lblSexo);

		JLabel lblValorSexo =
				new JLabel("Masculino");

		lblValorSexo.setBounds(
				125, 125, 240, 25);

		panelDatos.add(lblValorSexo);

		JLabel lblSangre = new JLabel(
				"Tipo de sangre:");

		lblSangre.setFont(
				new Font("Tahoma", Font.BOLD, 12));

		lblSangre.setBounds(
				20, 155, 110, 25);

		panelDatos.add(lblSangre);

		JLabel lblValorSangre =
				new JLabel("O+");

		lblValorSangre.setBounds(
				135, 155, 230, 25);

		panelDatos.add(lblValorSangre);

		// =====================================================
		// INFORMACIÓN MÉDICA
		// =====================================================

		JPanel panelMedico = new JPanel();

		panelMedico.setBackground(Color.WHITE);
		panelMedico.setLayout(null);

		panelMedico.setBorder(
				new TitledBorder(
						new LineBorder(
								new Color(200, 205, 210)),
						"Información médica",
						TitledBorder.LEFT,
						TitledBorder.TOP,
						new Font("Tahoma", Font.BOLD, 12),
						new Color(52, 73, 94)));

		panelMedico.setBounds(450, 335, 414, 200);

		getContentPane().add(panelMedico);

		JLabel lblMotivo = new JLabel(
				"Motivo de consulta:");

		lblMotivo.setFont(
				new Font("Tahoma", Font.BOLD, 12));

		lblMotivo.setBounds(
				15, 32, 150, 25);

		panelMedico.add(lblMotivo);

		JTextArea txtMotivo =
				new JTextArea(
						"Dolor abdominal y malestar general.");

		txtMotivo.setLineWrap(true);
		txtMotivo.setWrapStyleWord(true);
		txtMotivo.setEditable(false);

		JScrollPane scrollMotivo =
				new JScrollPane(txtMotivo);

		scrollMotivo.setBounds(
				15, 55, 380, 45);

		panelMedico.add(scrollMotivo);

		JLabel lblDiagnostico =
				new JLabel("Diagnóstico:");

		lblDiagnostico.setFont(
				new Font("Tahoma", Font.BOLD, 12));

		lblDiagnostico.setBounds(
				15, 105, 150, 25);

		panelMedico.add(lblDiagnostico);

		JTextArea txtDiagnostico =
				new JTextArea(
						"Gastritis aguda.");

		txtDiagnostico.setLineWrap(true);
		txtDiagnostico.setWrapStyleWord(true);
		txtDiagnostico.setEditable(false);

		JScrollPane scrollDiagnostico =
				new JScrollPane(txtDiagnostico);

		scrollDiagnostico.setBounds(
				15, 128, 380, 45);

		panelMedico.add(scrollDiagnostico);

		// =====================================================
		// BOTONES INFERIORES
		// =====================================================

		JButton btnConsultar =
				new JButton("Consultar");

		btnConsultar.setFont(
				new Font("Tahoma", Font.BOLD, 12));

		btnConsultar.setBounds(
				250, 555, 120, 35);

		getContentPane().add(btnConsultar);

		JButton btnLimpiar =
				new JButton("Limpiar");

		btnLimpiar.setFont(
				new Font("Tahoma", Font.BOLD, 12));

		btnLimpiar.setBounds(
				380, 555, 120, 35);

		getContentPane().add(btnLimpiar);

		JButton btnCerrar =
				new JButton("Cerrar");

		btnCerrar.setFont(
				new Font("Tahoma", Font.BOLD, 12));

		btnCerrar.setBounds(
				510, 555, 120, 35);

		getContentPane().add(btnCerrar);
	}
}
package gui;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class FrmConRecetaPaciente extends JInternalFrame {

	private static final long serialVersionUID = 1L;
	private JTextField txtDni;
	private JTable tblRecetas;

	public FrmConRecetaPaciente() {
		super("Consulta de Recetas por Paciente", true, true, true, true);
		setBounds(40, 30, 600, 380);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(245, 245, 245));
		panel.setLayout(null);
		setContentPane(panel);

		JLabel lblTitulo = new JLabel("CONSULTA DE RECETAS POR PACIENTE");
		lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblTitulo.setBounds(130, 15, 330, 25);
		panel.add(lblTitulo);

		JLabel lblDni = new JLabel("DNI Paciente:");
		lblDni.setBounds(30, 60, 90, 20);
		panel.add(lblDni);

		txtDni = new JTextField();
		txtDni.setBounds(120, 60, 150, 20);
		panel.add(txtDni);

		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.setBounds(290, 58, 100, 23);
		panel.add(btnBuscar);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(30, 100, 520, 220);
		panel.add(scrollPane);

		tblRecetas = new JTable();
		tblRecetas.setModel(new DefaultTableModel(
			new Object[][] {},
			new String[] { "N° Receta", "Fecha", "Medicamento", "Dosis", "Indicaciones", "Médico" }
		));
		scrollPane.setViewportView(tblRecetas);
	}
}
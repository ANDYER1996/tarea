package gui;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class FrmManEspecialidad extends JInternalFrame {

	private static final long serialVersionUID = 1L;
	private JTextField txtCodigo;
	private JTextField txtNombre;
	private JTextField txtDescripcion;
	private JTable tblEspecialidad;

	public FrmManEspecialidad() {
		// Habilitar controles del marco
		super("Mantenimiento de Especialidad", true, true, true, true);
		setBounds(40, 30, 560, 390);

		// Panel de contenido interno con fondo gris/blanco
		JPanel panel = new JPanel();
		panel.setBackground(new Color(245, 245, 245));
		panel.setLayout(null);
		setContentPane(panel);

		// Componentes gráficos
		JLabel lblTitulo = new JLabel("MANTENIMIENTO DE ESPECIALIDAD");
		lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblTitulo.setBounds(110, 15, 320, 25);
		panel.add(lblTitulo);

		JLabel lblCodigo = new JLabel("Código:");
		lblCodigo.setBounds(30, 60, 80, 20);
		panel.add(lblCodigo);

		txtCodigo = new JTextField();
		txtCodigo.setBounds(110, 60, 140, 20);
		panel.add(txtCodigo);

		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setBounds(30, 90, 80, 20);
		panel.add(lblNombre);

		txtNombre = new JTextField();
		txtNombre.setBounds(110, 90, 240, 20);
		panel.add(txtNombre);

		JLabel lblDescripcion = new JLabel("Descripción:");
		lblDescripcion.setBounds(30, 120, 80, 20);
		panel.add(lblDescripcion);

		txtDescripcion = new JTextField();
		txtDescripcion.setBounds(110, 120, 240, 20);
		panel.add(txtDescripcion);

		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.setBounds(380, 58, 110, 23);
		panel.add(btnRegistrar);

		JButton btnModificar = new JButton("Modificar");
		btnModificar.setBounds(380, 88, 110, 23);
		panel.add(btnModificar);

		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.setBounds(380, 118, 110, 23);
		panel.add(btnEliminar);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(30, 160, 480, 170);
		panel.add(scrollPane);

		tblEspecialidad = new JTable();
		tblEspecialidad.setModel(new DefaultTableModel(
			new Object[][] {},
			new String[] { "Código", "Nombre", "Descripción" }
		));
		scrollPane.setViewportView(tblEspecialidad);
	}
}
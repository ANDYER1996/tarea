package gui;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class FrmManMedico extends JInternalFrame {

	private static final long serialVersionUID = 1L;
	private JTextField txtCodigo;
	private JTextField txtNombre;
	private JTextField txtDni;
	private JTextField txtTelefono;
	private JComboBox<String> cboEspecialidad;
	private JTable tblMedico;

	public FrmManMedico() {
		super("Mantenimiento de Médico", true, true, true, true);
		setBounds(30, 20, 620, 430);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(245, 245, 245));
		panel.setLayout(null);
		setContentPane(panel);

		JLabel lblTitulo = new JLabel("MANTENIMIENTO DE MÉDICO");
		lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblTitulo.setBounds(180, 15, 260, 25);
		panel.add(lblTitulo);

		JLabel lblCodigo = new JLabel("Código:");
		lblCodigo.setBounds(30, 55, 80, 20);
		panel.add(lblCodigo);

		txtCodigo = new JTextField();
		txtCodigo.setBounds(120, 55, 120, 20);
		panel.add(txtCodigo);

		JLabel lblNombre = new JLabel("Nombres/Apellidos:");
		lblNombre.setBounds(30, 85, 120, 20);
		panel.add(lblNombre);

		txtNombre = new JTextField();
		txtNombre.setBounds(150, 85, 270, 20);
		panel.add(txtNombre);

		JLabel lblDni = new JLabel("DNI:");
		lblDni.setBounds(30, 115, 80, 20);
		panel.add(lblDni);

		txtDni = new JTextField();
		txtDni.setBounds(120, 115, 120, 20);
		panel.add(txtDni);

		JLabel lblTelefono = new JLabel("Teléfono:");
		lblTelefono.setBounds(250, 115, 70, 20);
		panel.add(lblTelefono);

		txtTelefono = new JTextField();
		txtTelefono.setBounds(310, 115, 110, 20);
		panel.add(txtTelefono);

		JLabel lblEspecialidad = new JLabel("Especialidad:");
		lblEspecialidad.setBounds(30, 145, 80, 20);
		panel.add(lblEspecialidad);

		cboEspecialidad = new JComboBox<String>();
		cboEspecialidad.addItem("Seleccione...");
		cboEspecialidad.addItem("Pediatría");
		cboEspecialidad.addItem("Cardiología");
		cboEspecialidad.addItem("Medicina General");
		cboEspecialidad.setBounds(120, 145, 200, 20);
		panel.add(cboEspecialidad);

		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.setBounds(460, 55, 110, 25);
		panel.add(btnRegistrar);

		JButton btnModificar = new JButton("Modificar");
		btnModificar.setBounds(460, 90, 110, 25);
		panel.add(btnModificar);

		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.setBounds(460, 125, 110, 25);
		panel.add(btnEliminar);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(30, 185, 540, 190);
		panel.add(scrollPane);

		tblMedico = new JTable();
		tblMedico.setModel(new DefaultTableModel(
			new Object[][] {},
			new String[] { "Código", "Nombres y Apellidos", "DNI", "Teléfono", "Especialidad" }
		));
		scrollPane.setViewportView(tblMedico);
	}
}
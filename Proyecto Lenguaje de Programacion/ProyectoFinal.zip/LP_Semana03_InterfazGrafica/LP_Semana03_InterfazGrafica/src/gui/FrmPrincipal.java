package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class FrmPrincipal extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JDesktopPane desktopPane;

	// =====================================================
	// INSTANCIAS DE LAS VENTANAS DEL SISTEMA
	// =====================================================
	FrmManPaciente frmManPaciente = new FrmManPaciente();
	FrmManEspecialidad frmManEspecialidad = new FrmManEspecialidad();
	FrmManMedico frmManMedico = new FrmManMedico();

	FrmProCita frmProCita = new FrmProCita();
	FrmProHistorial frmProHistorial = new FrmProHistorial();
	FrmProReceta frmProReceta = new FrmProReceta();

	FrmConHistorialMedico frmConHistorialMedico = new FrmConHistorialMedico();
	FrmConCitaPaciente frmConCitaPaciente = new FrmConCitaPaciente();
	FrmConRecetaPaciente frmConRecetaPaciente = new FrmConRecetaPaciente();

	FrmRepAnalisisPaciente frmRepAnalisisPaciente = new FrmRepAnalisisPaciente();
	FrmRepAnalisisHistorial frmRepAnalisisHistorial = new FrmRepAnalisisHistorial();
	FrmRepCitas frmRepCitas = new FrmRepCitas();

	// =====================================================
	// ELEMENTOS DEL MENU
	// =====================================================
	private JMenuItem mntmPaciente;
	private JMenuItem mntmEspecialidad;
	private JMenuItem mntmMedico;

	private JMenuItem mntmHistorial;
	private JMenuItem mntmCita;
	private JMenuItem mntmReceta;

	private JMenuItem mntmConsultaHistorial;
	private JMenuItem mntmConsulta02; // Cita por Paciente
	private JMenuItem mntmConsulta03; // Receta por paciente

	private JMenuItem mntmReporte01; // Análisis de Paciente
	private JMenuItem mntmReporte02; // Análisis de Historial
	private JMenuItem mntmReporte03; // Reporte de Citas

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmPrincipal frame = new FrmPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmPrincipal() {

		setIconImage(Toolkit.getDefaultToolkit().getImage(FrmPrincipal.class.getResource("/iconos/Heart.gif")));
		setTitle("Sistema de gestión de Establecimientos Médicos");
		setExtendedState(Frame.MAXIMIZED_BOTH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);

		// BARRA DE MENU
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		// MENU MANTENIMIENTO
		JMenu mnMantenimiento = new JMenu("Mantenimiento");
		mnMantenimiento.setIcon(new ImageIcon(FrmPrincipal.class.getResource("/iconos/Notes.gif")));
		menuBar.add(mnMantenimiento);

		mntmPaciente = new JMenuItem("Paciente");
		mntmPaciente.addActionListener(this);
		mnMantenimiento.add(mntmPaciente);

		mntmEspecialidad = new JMenuItem("Especialidad");
		mntmEspecialidad.addActionListener(this);
		mnMantenimiento.add(mntmEspecialidad);

		mntmMedico = new JMenuItem("Medico");
		mntmMedico.addActionListener(this);
		mnMantenimiento.add(mntmMedico);

		// MENU PROCESOS
		JMenu mnProcesos = new JMenu("Procesos");
		mnProcesos.setIcon(new ImageIcon(FrmPrincipal.class.getResource("/iconos/Handshake.gif")));
		menuBar.add(mnProcesos);

		mntmHistorial = new JMenuItem("Crear Historial Medico");
		mntmHistorial.addActionListener(this);
		mnProcesos.add(mntmHistorial);

		mntmCita = new JMenuItem("Cita");
		mntmCita.addActionListener(this);
		mnProcesos.add(mntmCita);

		mntmReceta = new JMenuItem("Receta");
		mntmReceta.addActionListener(this);
		mnProcesos.add(mntmReceta);

		// MENU CONSULTAS
		JMenu mnConsultas = new JMenu("Consultas");
		mnConsultas.setIcon(new ImageIcon(FrmPrincipal.class.getResource("/iconos/Search.gif")));
		menuBar.add(mnConsultas);

		mntmConsultaHistorial = new JMenuItem("Consultar Historial Medico");
		mntmConsultaHistorial.addActionListener(this);
		mnConsultas.add(mntmConsultaHistorial);

		mntmConsulta02 = new JMenuItem("Cita por Paciente");
		mntmConsulta02.addActionListener(this);
		mnConsultas.add(mntmConsulta02);

		mntmConsulta03 = new JMenuItem("Receta por paciente");
		mntmConsulta03.addActionListener(this);
		mnConsultas.add(mntmConsulta03);

		// MENU REPORTES
		JMenu mnReportes = new JMenu("Reportes");
		mnReportes.setIcon(new ImageIcon(FrmPrincipal.class.getResource("/iconos/Card file.gif")));
		menuBar.add(mnReportes);

		mntmReporte01 = new JMenuItem("Reporte de Análisis de Paciente");
		mntmReporte01.addActionListener(this);
		mnReportes.add(mntmReporte01);

		mntmReporte02 = new JMenuItem("Reporte de Análisis de Historial Médico");
		mntmReporte02.addActionListener(this);
		mnReportes.add(mntmReporte02);

		mntmReporte03 = new JMenuItem("Reporte de Citas");
		mntmReporte03.addActionListener(this);
		mnReportes.add(mntmReporte03);

		// PANEL PRINCIPAL Y DESKTOP PANE
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		desktopPane = new JDesktopPane();
		desktopPane.setBackground(SystemColor.textHighlight);
		contentPane.add(desktopPane, BorderLayout.CENTER);

		// REGISTRO DE TODAS LAS VENTANAS EN EL DESKTOP PANE
		desktopPane.add(frmManPaciente);
		desktopPane.add(frmManEspecialidad);
		desktopPane.add(frmManMedico);

		desktopPane.add(frmProHistorial);
		desktopPane.add(frmProCita);
		desktopPane.add(frmProReceta);

		desktopPane.add(frmConHistorialMedico);
		desktopPane.add(frmConCitaPaciente);
		desktopPane.add(frmConRecetaPaciente);

		desktopPane.add(frmRepAnalisisPaciente);
		desktopPane.add(frmRepAnalisisHistorial);
		desktopPane.add(frmRepCitas);
	}

	// CONTROLADOR DE EVENTOS
	public void actionPerformed(ActionEvent e) {
		// Mantenimiento
		if (e.getSource() == mntmPaciente) actionPerformedMntmPaciente(e);
		if (e.getSource() == mntmEspecialidad) actionPerformedMntmEspecialidad(e);
		if (e.getSource() == mntmMedico) actionPerformedMntmMedico(e);

		// Procesos
		if (e.getSource() == mntmHistorial) actionPerformedMntmHistorialJMenuItem(e);
		if (e.getSource() == mntmCita) actionPerformedMntmCitaJMenuItem(e);
		if (e.getSource() == mntmReceta) actionPerformedMntmRecetaJMenuItem(e);

		// Consultas
		if (e.getSource() == mntmConsultaHistorial) actionPerformedMntmConsultaHistorial(e);
		if (e.getSource() == mntmConsulta02) actionPerformedMntmConsulta02(e);
		if (e.getSource() == mntmConsulta03) actionPerformedMntmConsulta03(e);

		// Reportes
		if (e.getSource() == mntmReporte01) actionPerformedMntmReporte01(e);
		if (e.getSource() == mntmReporte02) actionPerformedMntmReporte02(e);
		if (e.getSource() == mntmReporte03) actionPerformedMntmReporte03(e);
	}

	// MÉTODOS PARA MOSTRAR CADA VENTANA
	protected void actionPerformedMntmPaciente(ActionEvent e) {
		frmManPaciente.setVisible(true);
		frmManPaciente.toFront();
	}

	protected void actionPerformedMntmEspecialidad(ActionEvent e) {
		frmManEspecialidad.setVisible(true);
		frmManEspecialidad.toFront();
	}

	protected void actionPerformedMntmMedico(ActionEvent e) {
		frmManMedico.setVisible(true);
		frmManMedico.toFront();
	}

	protected void actionPerformedMntmHistorialJMenuItem(ActionEvent e) {
		frmProHistorial.setVisible(true);
		frmProHistorial.toFront();
	}

	protected void actionPerformedMntmCitaJMenuItem(ActionEvent e) {
		frmProCita.setVisible(true);
		frmProCita.toFront();
	}

	protected void actionPerformedMntmRecetaJMenuItem(ActionEvent e) {
		frmProReceta.setVisible(true);
		frmProReceta.toFront();
	}

	protected void actionPerformedMntmConsultaHistorial(ActionEvent e) {
		frmConHistorialMedico.setVisible(true);
		frmConHistorialMedico.toFront();
	}

	protected void actionPerformedMntmConsulta02(ActionEvent e) {
		frmConCitaPaciente.setVisible(true);
		frmConCitaPaciente.toFront();
	}

	protected void actionPerformedMntmConsulta03(ActionEvent e) {
		frmConRecetaPaciente.setVisible(true);
		frmConRecetaPaciente.toFront();
	}

	protected void actionPerformedMntmReporte01(ActionEvent e) {
		frmRepAnalisisPaciente.setVisible(true);
		frmRepAnalisisPaciente.toFront();
	}

	protected void actionPerformedMntmReporte02(ActionEvent e) {
		frmRepAnalisisHistorial.setVisible(true);
		frmRepAnalisisHistorial.toFront();
	}

	protected void actionPerformedMntmReporte03(ActionEvent e) {
		frmRepCitas.setVisible(true);
		frmRepCitas.toFront();
	}
}
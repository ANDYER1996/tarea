package gui;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FrmProHistorial extends JInternalFrame {

	private JTextField txtNombres;
	private JTextField txtApellidos;
	private JTextField txtFechaNacimiento;
	private JTextField txtTipoSangre;
	private JTextField txtDNI;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmProHistorial frame = new FrmProHistorial();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmProHistorial() {
		getContentPane().setForeground(new Color(0, 0, 0));

		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setResizable(true);
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);

		setTitle("Historial Médico");
		setBounds(100, 100, 850, 620);

		getContentPane().setLayout(null);
		getContentPane().setBackground(new Color(255, 250, 205));

		// =====================================================
		// CABECERA
		// =====================================================

		JPanel panelCabecera = new JPanel();
		panelCabecera.setBackground(new Color(52, 73, 94));
		panelCabecera.setBounds(0, 0, 834, 70);
		panelCabecera.setLayout(null);
		getContentPane().add(panelCabecera);

		JLabel lblTitulo = new JLabel("HISTORIAL MÉDICO");
		lblTitulo.setForeground(Color.WHITE);
		lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblTitulo.setBounds(25, 12, 300, 25);
		panelCabecera.add(lblTitulo);

		JLabel lblDescripcion = new JLabel(
				"Registro de información del paciente");
		lblDescripcion.setForeground(new Color(220, 220, 220));
		lblDescripcion.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblDescripcion.setBounds(27, 39, 300, 20);
		panelCabecera.add(lblDescripcion);

		JLabel lblCodigo = new JLabel("Codigo del Historial: 12344");
		lblCodigo.setForeground(Color.WHITE);
		lblCodigo.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblCodigo.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCodigo.setBounds(546, 17, 228, 20);
		panelCabecera.add(lblCodigo);

		// =====================================================
		// DATOS DEL PACIENTE
		// =====================================================

		JPanel panelPaciente = new JPanel();
		panelPaciente.setBackground(Color.WHITE);
		panelPaciente.setLayout(null);
		panelPaciente.setBorder(new TitledBorder(
				new LineBorder(new Color(200, 205, 210)),
				"Datos del paciente",
				TitledBorder.LEFT,
				TitledBorder.TOP,
				new Font("Tahoma", Font.BOLD, 12),
				new Color(52, 73, 94)));

		panelPaciente.setBounds(20, 85, 390, 270);
		getContentPane().add(panelPaciente);

		JLabel lblNombres = new JLabel("Nombres");
		lblNombres.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNombres.setBounds(20, 35, 120, 25);
		panelPaciente.add(lblNombres);

		txtNombres = new JTextField();
		txtNombres.setBounds(145, 35, 215, 25);
		panelPaciente.add(txtNombres);

		JLabel lblApellidos = new JLabel("Apellidos");
		lblApellidos.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblApellidos.setBounds(20, 70, 120, 25);
		panelPaciente.add(lblApellidos);

		txtApellidos = new JTextField();
		txtApellidos.setBounds(145, 70, 215, 25);
		panelPaciente.add(txtApellidos);

		JLabel lblFecha = new JLabel("Fecha nacimiento");
		lblFecha.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblFecha.setBounds(20, 105, 120, 25);
		panelPaciente.add(lblFecha);

		txtFechaNacimiento = new JTextField();
		txtFechaNacimiento.setBounds(145, 105, 215, 25);
		panelPaciente.add(txtFechaNacimiento);

		JLabel lblDni = new JLabel("DNI");
		lblDni.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblDni.setBounds(20, 140, 120, 25);
		panelPaciente.add(lblDni);

		txtDNI = new JTextField();
		txtDNI.setBounds(145, 140, 215, 25);
		panelPaciente.add(txtDNI);

		JLabel lblSexo = new JLabel("Sexo");
		lblSexo.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblSexo.setBounds(20, 175, 120, 25);
		panelPaciente.add(lblSexo);

		JComboBox<String> cmbSexo = new JComboBox<String>();
		cmbSexo.addItem("Seleccione");
		cmbSexo.addItem("Masculino");
		cmbSexo.addItem("Femenino");
		cmbSexo.setBounds(145, 175, 215, 25);
		panelPaciente.add(cmbSexo);

		JLabel lblSangre = new JLabel("Tipo de sangre");
		lblSangre.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblSangre.setBounds(20, 210, 120, 25);
		panelPaciente.add(lblSangre);

		txtTipoSangre = new JTextField();
		txtTipoSangre.setBounds(145, 210, 215, 25);
		panelPaciente.add(txtTipoSangre);

		// =====================================================
		// CONSULTA MÉDICA
		// =====================================================

		JPanel panelConsulta = new JPanel();
		panelConsulta.setBackground(Color.WHITE);
		panelConsulta.setLayout(null);
		panelConsulta.setBorder(new TitledBorder(
				new LineBorder(new Color(200, 205, 210)),
				"Consulta médica",
				TitledBorder.LEFT,
				TitledBorder.TOP,
				new Font("Tahoma", Font.BOLD, 12),
				new Color(52, 73, 94)));

		panelConsulta.setBounds(425, 85, 390, 270);
		getContentPane().add(panelConsulta);

		JLabel lblMotivo = new JLabel("Motivo de consulta");
		lblMotivo.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblMotivo.setBounds(20, 35, 180, 25);
		panelConsulta.add(lblMotivo);

		JTextArea txtMotivo = new JTextArea();
		txtMotivo.setLineWrap(true);
		txtMotivo.setWrapStyleWord(true);

		JScrollPane scrollMotivo = new JScrollPane(txtMotivo);
		scrollMotivo.setBounds(20, 62, 345, 70);
		panelConsulta.add(scrollMotivo);

		JLabel lblDiagnostico = new JLabel("Diagnóstico");
		lblDiagnostico.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblDiagnostico.setBounds(20, 145, 180, 25);
		panelConsulta.add(lblDiagnostico);

		JTextArea txtDiagnostico = new JTextArea();
		txtDiagnostico.setLineWrap(true);
		txtDiagnostico.setWrapStyleWord(true);

		JScrollPane scrollDiagnostico = new JScrollPane(txtDiagnostico);
		scrollDiagnostico.setBounds(20, 172, 345, 70);
		panelConsulta.add(scrollDiagnostico);

		// =====================================================
		// ALERGIAS
		// =====================================================

		JPanel panelAlergias = new JPanel();
		panelAlergias.setBackground(Color.WHITE);
		panelAlergias.setLayout(null);
		panelAlergias.setBorder(new TitledBorder(
				new LineBorder(new Color(200, 205, 210)),
				"Reacciones alérgicas",
				TitledBorder.LEFT,
				TitledBorder.TOP,
				new Font("Tahoma", Font.BOLD, 12),
				new Color(52, 73, 94)));

		panelAlergias.setBounds(20, 370, 390, 110);
		getContentPane().add(panelAlergias);

		JCheckBox chkAspirina = new JCheckBox("Aspirina");
		chkAspirina.setBackground(Color.WHITE);
		chkAspirina.setBounds(15, 30, 100, 25);
		panelAlergias.add(chkAspirina);

		JCheckBox chkPenicilina = new JCheckBox("Penicilina");
		chkPenicilina.setBackground(Color.WHITE);
		chkPenicilina.setBounds(15, 67, 100, 25);
		panelAlergias.add(chkPenicilina);

		// =====================================================
		// ANTECEDENTES
		// =====================================================

		JPanel panelAntecedentes = new JPanel();
		panelAntecedentes.setBackground(Color.WHITE);
		panelAntecedentes.setLayout(null);
		panelAntecedentes.setBorder(new TitledBorder(
				new LineBorder(new Color(200, 205, 210)),
				"Antecedentes médicos",
				TitledBorder.LEFT,
				TitledBorder.TOP,
				new Font("Tahoma", Font.BOLD, 12),
				new Color(52, 73, 94)));

		panelAntecedentes.setBounds(425, 370, 390, 110);
		getContentPane().add(panelAntecedentes);

		JCheckBox chkHipertension = new JCheckBox("Hipertensión");
		chkHipertension.setBackground(Color.WHITE);
		chkHipertension.setBounds(10, 30, 110, 25);
		panelAntecedentes.add(chkHipertension);

		JCheckBox chkAsma = new JCheckBox("Asma");
		chkAsma.setBackground(Color.WHITE);
		chkAsma.setBounds(120, 30, 70, 25);
		panelAntecedentes.add(chkAsma);

		JCheckBox chkDiabetes = new JCheckBox("Diabetes");
		chkDiabetes.setBackground(Color.WHITE);
		chkDiabetes.setBounds(190, 30, 90, 25);
		panelAntecedentes.add(chkDiabetes);

		JCheckBox chkAnemia = new JCheckBox("Anemia");
		chkAnemia.setBackground(Color.WHITE);
		chkAnemia.setBounds(280, 30, 80, 25);
		panelAntecedentes.add(chkAnemia);

		JCheckBox chkColesterol = new JCheckBox("Colesterol alto");
		chkColesterol.setBackground(Color.WHITE);
		chkColesterol.setBounds(10, 62, 115, 25);
		panelAntecedentes.add(chkColesterol);

		JCheckBox chkCancer = new JCheckBox("Cáncer");
		chkCancer.setBackground(Color.WHITE);
		chkCancer.setBounds(125, 62, 80, 25);
		panelAntecedentes.add(chkCancer);

		JCheckBox chkLeucemia = new JCheckBox("Leucemia");
		chkLeucemia.setBackground(Color.WHITE);
		chkLeucemia.setBounds(205, 62, 90, 25);
		panelAntecedentes.add(chkLeucemia);

		JCheckBox chkTuberculosis = new JCheckBox("Tuberculosis");
		chkTuberculosis.setBackground(Color.WHITE);
		chkTuberculosis.setBounds(295, 62, 90, 25);
		panelAntecedentes.add(chkTuberculosis);

		// =====================================================
		// BOTONES
		// =====================================================

		JButton btnGrabar = new JButton("Grabar");
		btnGrabar.setForeground(new Color(34, 139, 34));
		btnGrabar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnGrabar.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnGrabar.setBounds(225, 510, 120, 35);
		getContentPane().add(btnGrabar);

		JButton btnLimpiar = new JButton("Limpiar");
		btnLimpiar.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnLimpiar.setBounds(355, 510, 120, 35);
		getContentPane().add(btnLimpiar);

		JButton btnNuevoPaciente = new JButton("Nuevo Paciente");
		btnNuevoPaciente.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNuevoPaciente.setBounds(485, 510, 145, 35);
		getContentPane().add(btnNuevoPaciente);
	}
}
package gui;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FrmProRegistro extends JInternalFrame implements ActionListener {

	private JTextField textField;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JButton btnNewButton;
	private JTextField textField_5;
	private JTextField textField_6;
	private JButton btnCancelar;
	private JLabel lblEstatura;
	private JTextField textField_7;
	private JTextField textField_8;
	private JLabel lblPeso;
	private JTextField textField_9;
	private JLabel lblTipoSangre;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmProRegistro frame = new FrmProRegistro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public FrmProRegistro() {
		getContentPane().setForeground(new Color(0, 0, 0));
		getContentPane().setBackground(new Color(255, 255, 204));

		setTitle("Registrar Paciente");
		setClosable(true);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setResizable(true);
		setMaximizable(true);
		setIconifiable(true);
		setBounds(100, 100, 734, 577);

		getContentPane().setLayout(null);

		// TITULO
		JLabel lblTitulo = new JLabel("Registro de Paciente");
		lblTitulo.setBackground(new Color(211, 211, 211));
		lblTitulo.setForeground(new Color(0, 191, 255));
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setFont(new Font("HP Simplified", Font.BOLD, 36));
		lblTitulo.setBounds(20, 20, 680, 45);
		getContentPane().add(lblTitulo);

		// NOMBRE DEL PACIENTE
		JLabel lblPaciente = new JLabel("Nombre:");
		lblPaciente.setBounds(55, 105, 80, 24);
		getContentPane().add(lblPaciente);

		textField = new JTextField();
		textField.setBounds(145, 107, 210, 22);
		getContentPane().add(textField);
		textField.setColumns(10);

		// DNI
		JLabel lblDniPaciente = new JLabel("DNI:");
		lblDniPaciente.setBounds(405, 105, 60, 24);
		getContentPane().add(lblDniPaciente);

		textField_5 = new JTextField();
		textField_5.setBounds(470, 107, 190, 22);
		getContentPane().add(textField_5);
		textField_5.setColumns(10);

		// APELLIDO
		JLabel lblApellido = new JLabel("Apellido:");
		lblApellido.setBounds(55, 150, 80, 24);
		getContentPane().add(lblApellido);

		textField_2 = new JTextField();
		textField_2.setBounds(145, 152, 210, 22);
		getContentPane().add(textField_2);
		textField_2.setColumns(10);

		// ESTATURA
		lblEstatura = new JLabel("Estatura:");
		lblEstatura.setBounds(395, 150, 70, 24);
		getContentPane().add(lblEstatura);

		textField_7 = new JTextField();
		textField_7.setBounds(470, 151, 190, 22);
		getContentPane().add(textField_7);
		textField_7.setColumns(10);

		// PESO
		lblPeso = new JLabel("Peso:");
		lblPeso.setBounds(55, 195, 80, 24);
		getContentPane().add(lblPeso);

		textField_8 = new JTextField();
		textField_8.setBounds(145, 196, 210, 22);
		getContentPane().add(textField_8);
		textField_8.setColumns(10);

		// TIPO DE SANGRE
		lblTipoSangre = new JLabel("Tipo Sangre:");
		lblTipoSangre.setBounds(395, 195, 90, 24);
		getContentPane().add(lblTipoSangre);

		textField_9 = new JTextField();
		textField_9.setBounds(470, 196, 160, 22);
		getContentPane().add(textField_9);
		textField_9.setColumns(10);

		// INFORMACION ADICIONAL
		JLabel lblInformacion = new JLabel("Motivo de Registro:");
		lblInformacion.setBounds(55, 244, 150, 24);
		getContentPane().add(lblInformacion);

		textField_4 = new JTextField();
		textField_4.setBounds(55, 279, 605, 70);
		getContentPane().add(textField_4);
		textField_4.setColumns(10);

		// FECHA
		JLabel lblFecha = new JLabel("Fecha de consulta:");
		lblFecha.setBounds(55, 415, 111, 24);
		getContentPane().add(lblFecha);

		textField_3 = new JTextField();
		textField_3.setBounds(164, 416, 210, 22);
		getContentPane().add(textField_3);
		textField_3.setColumns(10);

		// NUMERO DE REGISTRO
		JLabel lblRegistro = new JLabel("Codigo de Registro:");
		lblRegistro.setBounds(405, 415, 121, 24);
		getContentPane().add(lblRegistro);

		textField_6 = new JTextField();
		textField_6.setBounds(524, 416, 141, 22);
		getContentPane().add(textField_6);
		textField_6.setColumns(10);

		// BOTON GUARDAR
		btnNewButton = new JButton("Registrar");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.setForeground(new Color(0, 128, 0));
		btnNewButton.setBounds(325, 506, 130, 30);
		btnNewButton.addActionListener(this);
		getContentPane().add(btnNewButton);

		// BOTON CANCELAR
		btnCancelar = new JButton("Cancelar");
		btnCancelar.setForeground(new Color(255, 69, 0));
		btnCancelar.setBounds(325, 465, 130, 30);
		btnCancelar.addActionListener(this);
		getContentPane().add(btnCancelar);
	}

	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == btnCancelar) {
			btnCancelarActionPerformed(e);
		}

		if (e.getSource() == btnNewButton) {
			btnNewButtonActionPerformed(e);
		}
	}

	protected void btnNewButtonActionPerformed(ActionEvent e) {

	}

	protected void btnCancelarActionPerformed(ActionEvent e) {

	}
}
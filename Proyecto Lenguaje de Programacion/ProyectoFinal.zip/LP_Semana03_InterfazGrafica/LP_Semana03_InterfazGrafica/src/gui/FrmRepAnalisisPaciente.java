package gui;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class FrmRepAnalisisPaciente extends JInternalFrame {

	private static final long serialVersionUID = 1L;
	private JTextArea txtReporte;

	public FrmRepAnalisisPaciente() {
		super("Reporte de Análisis de Paciente", true, true, true, true);
		setBounds(50, 30, 550, 400);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(245, 245, 245));
		panel.setLayout(null);
		setContentPane(panel);

		JLabel lblTitulo = new JLabel("REPORTE DE ANÁLISIS DE PACIENTES");
		lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblTitulo.setBounds(120, 15, 320, 25);
		panel.add(lblTitulo);

		JButton btnGenerar = new JButton("Generar Reporte");
		btnGenerar.setBounds(30, 55, 150, 25);
		panel.add(btnGenerar);

		JButton btnImprimir = new JButton("Imprimir / Exportar");
		btnImprimir.setBounds(190, 55, 150, 25);
		panel.add(btnImprimir);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(30, 95, 470, 240);
		panel.add(scrollPane);

		txtReporte = new JTextArea();
		txtReporte.setFont(new Font("Monospaced", Font.PLAIN, 12));
		scrollPane.setViewportView(txtReporte);
	}
}